# 1. Use python environment: Windows,Python 2.7.12 
# 2. Editor: Sublime Text 3
# 3. This Project is to finished the simple WebServer
# 4. Double click startup.bat run Server
