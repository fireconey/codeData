[
  {
    "id":1,
    "name":"Jason",
    "placeOfBirth":"hubei wuhan"
  },
  {
    "id":2,
    "name":"Tom",
    "placeOfBirth":"usa newyork"
  },
  {
    "id":3,
    "name":"Lucy",
    "placeOfBirth":"hubei wuhan"
  },
  {
    "id":4,
    "name":"Davie",
    "placeOfBirth":"hubei wuhan"
  },
  {
    "id":5,
    "name":"Bao",
    "placeOfBirth":"hubei wuhan"
  },
  {
    "id":6,
    "name":"Marry",
    "placeOfBirth":"hubei wuhan"
  }
]
