var test=function(){
  alert("this is a test")
}
